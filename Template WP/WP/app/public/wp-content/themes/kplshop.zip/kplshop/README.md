# Store Front Child

Modelo Básico de como deve ser um tema filho.
